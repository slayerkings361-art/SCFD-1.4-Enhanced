# SCFD 1.4 Enhanced Demo (standalone Android preview)
This packages the existing enhanced HTML prototype into an Android WebView. It is offline, foreground demo only. No real ESP32/Firebase connection, native background notifications or certified flood warnings. It uses a separate package ID to avoid overwriting SCFD 1.3. Not a replacement for the original Android source.

## Build using GitHub Actions
1. Extract this archive. Create a new GitHub repository (SCFD-1.4-demo).
2. Upload/commit all extracted contents to the repository root, including `.github/workflows/build-apk.yml`. If the website hides `.github`, use GitHub's Create new file with the path `.github/workflows/build-apk.yml`, then paste the included YAML. The app, Gradle files and workflow must be at the root, not under another folder.
3. Open Actions > Build SCFD 1.4 Demo APK > Run workflow (if the push did not start it automatically).
4. Open the successful run and download the artifact SCFD-1.4-Enhanced-Demo-APK. Extract its ZIP and open the APK on Android. Allow installation from the source only if you trust the build.

The GitHub runner creates a debug-signed APK. Different builds can use different signing keys; if updating fails, uninstall only this standalone demo before reinstalling (its data may be lost). The original SCFD 1.3 is separate.

## Verification
HTML JavaScript syntax and XML well-formedness checked locally. Android compilation, installation, audio, CSV export and runtime behavior have not been verified here because Android SDK and external downloads are unavailable. Test all five tabs, thresholds, demo alarms, offline toggle and both CSV exports on the phone. Demo data is not actual telemetry. CSV save uses Android's system document picker. Settings/history are session-only as in the original HTML.
