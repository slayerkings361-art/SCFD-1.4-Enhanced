package ph.smartcar.flooddefense.enhanceddemo;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final String PAGE = "file:///android_asset/index.html";
    private static final int EXPORT = 14;
    private WebView web;
    private String pendingCsv;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        if (state != null) pendingCsv = state.getString("pendingCsv");
        web = new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(false);
        web.getSettings().setAllowContentAccess(false);
        web.getSettings().setAllowFileAccessFromFileURLs(false);
        web.getSettings().setAllowUniversalAccessFromFileURLs(false);
        web.getSettings().setBlockNetworkLoads(true);
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) { return !PAGE.equals(request.getUrl().toString()); }
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) { return !PAGE.equals(url); }
        });
        web.addJavascriptInterface(new ExportBridge(), "AndroidExport");
        setContentView(web);
        web.loadUrl(PAGE);
    }
    public class ExportBridge {
        @JavascriptInterface public void saveCsv(String name, String csv) {
            if (name == null || !name.matches("SCFD_[A-Za-z0-9_]+\\.csv") || csv == null || csv.length() > 1000000) return;
            runOnUiThread(() -> {
                if (pendingCsv != null) return;
                pendingCsv = csv;
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("text/csv");
                intent.putExtra(Intent.EXTRA_TITLE, name);
                try { startActivityForResult(intent, EXPORT); }
                catch (Exception e) { pendingCsv = null; Toast.makeText(MainActivity.this, "No file picker available", Toast.LENGTH_SHORT).show(); }
            });
        }
    }
    @Override protected void onSaveInstanceState(Bundle out) { super.onSaveInstanceState(out); if (pendingCsv != null) out.putString("pendingCsv", pendingCsv); }
    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request != EXPORT) return;
        String csv = pendingCsv;
        pendingCsv = null;
        if (result != RESULT_OK || data == null || data.getData() == null || csv == null) return;
        try (OutputStream out = getContentResolver().openOutputStream(data.getData(), "w")) {
            if (out == null) throw new java.io.IOException("No output stream");
            out.write(csv.getBytes(StandardCharsets.UTF_8));
            Toast.makeText(this, "CSV saved", Toast.LENGTH_SHORT).show();
        } catch (Exception e) { Toast.makeText(this, "CSV export failed", Toast.LENGTH_SHORT).show(); }
    }
    @Override protected void onDestroy() { if(web != null) {web.removeJavascriptInterface("AndroidExport");web.destroy();} super.onDestroy(); }
}
